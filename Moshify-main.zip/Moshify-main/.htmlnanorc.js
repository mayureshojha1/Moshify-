module.exports = {
    minifySvg: false,
};
